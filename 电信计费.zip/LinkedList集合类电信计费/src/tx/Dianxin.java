package tx;
import telcomuser.*;
import java.util.Date;

import telcomuser.TelcomUser;

public class Dianxin implements Tongxin{
	   public double feePerMinute(){
		   return  (double)0.3;
	   }
	}