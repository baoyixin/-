package tx;
import telcomuser.*;
public interface Tongxin {
   double feePerMinute();
}
