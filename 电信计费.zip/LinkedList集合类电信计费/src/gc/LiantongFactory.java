package gc;
import telcomuser.TelcomUser;
import tx.*;
public  class LiantongFactory implements Factory {

	public Tongxin creat() {
		return new Liantong();
	}
}
