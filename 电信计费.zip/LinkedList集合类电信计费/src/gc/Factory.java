package gc;
import tx.*;
public interface Factory {
    public  Tongxin creat();
}
